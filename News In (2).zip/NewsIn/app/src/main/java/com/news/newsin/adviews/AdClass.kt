package com.android.newsin.adviews

import com.google.android.gms.ads.AdLoader

class AdClass {
    var adLoader: AdLoader? = null
}