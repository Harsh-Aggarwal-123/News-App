package com.news.newsin

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.android.newsin.adviews.NativeTemplateStyle
import com.news.newsin.adviews.TemplateView
import com.android.newsin.model.Article
import com.news.newsin.model.Utils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions


class Adapter(private val articles: List<Article>, private val  context: Context) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == IS_AD) {
            val view: View = LayoutInflater.from(context).inflate(R.layout.my_ad_cardview, parent, false)
            AdViewHolder(view)
        }
        else {
            val view: View = LayoutInflater.from(context).inflate(R.layout.item_discover, parent, false)
            ItemViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        if (getItemViewType(position) == IS_AD) {
            val adv = holder as AdViewHolder
            loadAds(adv)

        } else {

            val holders = holder as ItemViewHolder

            val model: Article = articles[position]
            val requestOptions: RequestOptions = RequestOptions()
                .placeholder(Utils.randomDrawbleColor)
                .error(Utils.randomDrawbleColor)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
            Glide.with(context)
                .load(model.urlToImage)
                .apply(requestOptions)
                .listener(object : RequestListener<Drawable?> {
                    override fun onLoadFailed(
                        e: GlideException?,
                        model: Any?,
                        target: Target<Drawable?>?,
                        isFirstResource: Boolean
                    ): Boolean {
                        holders.progressBar.visibility = View.GONE
                        return false
                    }

                    override fun onResourceReady(
                        resource: Drawable?,
                        model: Any?,
                        target: Target<Drawable?>?,
                        dataSource: DataSource?,
                        isFirstResource: Boolean
                    ): Boolean {
                        holders.progressBar.visibility = View.GONE
                        return false
                    }
                })
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(holders.imageView)
            holders.title.text = model.title
            holders.desc.text = model.description
            holders.source.text = model.source?.name
            holders.time.text =
                String.format(" • %s", Utils.dateToTimeFormat(model.publishedAt))
            holders.published_ad.text = Utils.DateFormat(model.publishedAt)
            holders.author.text = model.author

            holders.itemView.setOnClickListener {
                val article = articles[position]
                val i = Intent(Intent.ACTION_VIEW)
                i.data = Uri.parse(article.url)
                startActivity(context,i,null)
            }


        }
    }

    override fun getItemCount(): Int {
//        Log.d("MyTag",articles.size.toString())
        return articles.size

    }

    override fun getItemViewType(position: Int): Int {

//        if ((position+1) % 5 == 0 && (position+1) != 1) {
//            return IS_AD
//        }
        return  NOT_Ad

    }

    inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var title: TextView = itemView.findViewById(R.id.title)
        var desc: TextView = itemView.findViewById(R.id.desc)
        var author: TextView = itemView.findViewById(R.id.author)
        var published_ad: TextView = itemView.findViewById(R.id.publishedAt)
        var source: TextView = itemView.findViewById(R.id.source)
        var time: TextView = itemView.findViewById(R.id.time)
        var imageView: ImageView = itemView.findViewById(R.id.img)
        var progressBar: ProgressBar = itemView.findViewById(R.id.prograss_load_photo)
    }

    inner class AdViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val template: TemplateView = itemView.findViewById(R.id.id_ad_template_view)
        val rootLayout:RelativeLayout=itemView.findViewById(R.id.rootLayout)

        fun setNativeAd(nativeAd: NativeAd?) {
            if (nativeAd != null) {
                template.setNativeAd(nativeAd)
            }
        }

        init {
            val styles = NativeTemplateStyle.Builder().build()
            template.setStyles(styles)
        }
    }


    private fun loadAds(adv : AdViewHolder){

        val adLoader: AdLoader = AdLoader.Builder(context,"ca-app-pub-8438387212221904/8218418440")
            .forNativeAd { ad : NativeAd ->
                // Show the ad.
                if (adv.itemView.rootView.visibility==View.GONE){
                    adv.itemView.rootView.visibility=View.VISIBLE
                }

                adv.template.setNativeAd(ad)

            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    // Handle the failure by logging, altering the UI, and so on.
                    if (adv.itemView.rootView.visibility==View.VISIBLE){
                        adv.itemView.rootView.visibility=View.GONE
                    }
                }
            })
            .withNativeAdOptions(
                NativeAdOptions.Builder()
                    // Methods in the NativeAdOptions.Builder class can be
                    // used here to specify individual options settings.
                    .build())
            .build()

        if (adLoader.isLoading){
            if (adv.itemView.rootView.visibility==View.VISIBLE){
                adv.itemView.rootView.visibility=View.GONE
            }
        }

        val adReq= AdRequest.Builder().build()
        adLoader.loadAds(adReq,2)

    }


    companion object {
        private const val IS_AD = 0
        private const val NOT_Ad = 1
    }
}



//    fun setList(list: List<ItemClass>?) {
//        objects.addAll(list!!)
//    }
//
//    fun setAd(nativeAd: List<NativeAd>?) {
//        objects.addAll(nativeAd!!)
//        notifyDataSetChanged()
//    }
//
//    fun setObject(`object`: ArrayList<Any>?) {
//        objects.clear()
//        objects.addAll(`object`!!)
//        notifyDataSetChanged()
//    }

//class Adapter(articles: List<Article>, context: Context) : RecyclerView.Adapter<Adapter.MyViewHolder>() {
//
//    private val articles: List<Article> = articles
//
//    private val context: Context = context
//
//    val newsItem = 0
//    val adItem = 1
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
//        if (viewType == newsItem) {
//            val view: View =
//                LayoutInflater.from(context).inflate(R.layout.item_discover, parent, false)
//            return MyViewHolder(view)
////            MessageAdapter.ViewHolder
//        } else {
//            val view: View =
//                LayoutInflater.from(context).inflate(R.layout.my_ad_cardview, parent, false);
//            return MyViewHolder(view)
//        }
//
//
//    }
//
//
//    override fun getItemViewType(position: Int): Int {
//        return if (articles.size % 4 == 0 && articles.isNotEmpty()) {
//            adItem
//        } else {
//            newsItem
//        }
//    }
//
//    override fun onBindViewHolder(holders: MyViewHolder, position: Int) {
//
//        val model: Article = articles[position]
//        val requestOptions: RequestOptions = RequestOptions()
//            .placeholder(Utils.randomDrawbleColor)
//            .error(Utils.randomDrawbleColor)
//            .diskCacheStrategy(DiskCacheStrategy.ALL)
//            .centerCrop()
//        Glide.with(context)
//            .load(model.urlToImage)
//            .apply(requestOptions)
//            .listener(object : RequestListener<Drawable?> {
//                override fun onLoadFailed(
//                    e: GlideException?,
//                    model: Any?,
//                    target: Target<Drawable?>?,
//                    isFirstResource: Boolean
//                ): Boolean {
//                    holders.progressBar.visibility = View.GONE
//                    return false
//                }
//
//                override fun onResourceReady(
//                    resource: Drawable?,
//                    model: Any?,
//                    target: Target<Drawable?>?,
//                    dataSource: DataSource?,
//                    isFirstResource: Boolean
//                ): Boolean {
//                    holders.progressBar.visibility = View.GONE
//                    return false
//                }
//            })
//            .transition(DrawableTransitionOptions.withCrossFade())
//            .into(holders.imageView)
//        holders.title.text = model.title
//        holders.desc.text = model.description
//        holders.source.text = model.source?.name
//        holders.time.text =
//            String.format(" • %s", Utils.dateToTimeFormat(model.publishedAt))
//        holders.published_ad.text = Utils.DateFormat(model.publishedAt)
//        holders.author.text = model.author
//    }
//
//    override fun getItemCount(): Int {
//        return articles.size
//    }
//
//    inner class MyViewHolder(itemView: View) :
//        RecyclerView.ViewHolder(itemView) {
//        var title: TextView = itemView.findViewById(R.id.title)
//        var desc: TextView = itemView.findViewById(R.id.desc)
//        var author: TextView = itemView.findViewById(R.id.author)
//        var published_ad: TextView = itemView.findViewById(R.id.publishedAt)
//        var source: TextView = itemView.findViewById(R.id.source)
//        var time: TextView = itemView.findViewById(R.id.time)
//        var imageView: ImageView = itemView.findViewById(R.id.img)
//        var progressBar: ProgressBar = itemView.findViewById(R.id.prograss_load_photo)
//        var addTemplateView: TemplateView = itemView.findViewById(R.id.id_ad_template_view)
//
//        fun loadAds() {
//
//            val adLoader = AdLoader.Builder(context, "ca-app-pub-3940256099942544/2247696110")
//                .forNativeAd { ad: NativeAd ->
//                    // Show the ad.
//
//                }
//                .withAdListener(object : AdListener() {
//                    override fun onAdFailedToLoad(adError: LoadAdError) {
//                        // Handle the failure by logging, altering the UI, and so on.
//                    }
//                })
//                .withNativeAdOptions(
//                    NativeAdOptions.Builder()
//                        // Methods in the NativeAdOptions.Builder class can be
//                        // used here to specify individual options settings.
//                        .build()
//                )
//                .build()
//
//
//        }
//
//    }
//
//
//}