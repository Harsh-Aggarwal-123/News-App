package com.news.newsin

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
import com.news.newsin.api.ApiClient
import com.android.newsin.api.ApiInterface
import com.android.newsin.model.Article
import com.android.newsin.model.News
import com.news.newsin.model.Utils
import com.google.android.gms.ads.*
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*


class MainActivity : AppCompatActivity(), OnRefreshListener {

    private var articles: MutableList<Article> = ArrayList<Article>()
    private var adapter: Adapter? = null
    private var category: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        MobileAds.initialize(this)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.itemAnimator = DefaultItemAnimator()


        category = "general"
        refreshLayout.setOnRefreshListener(this)
        loadJSON("", "")

        t1.setOnClickListener {

            if ( recyclerView.visibility==View.GONE && contactLayout.visibility==View.VISIBLE) {
                recyclerView.visibility = View.VISIBLE
                contactLayout.visibility = View.GONE
            }


            if (category != "general") {
                loadJSON("", "")
                category = "general"
            }
        }

        t2.setOnClickListener {

            if ( recyclerView.visibility==View.GONE && contactLayout.visibility==View.VISIBLE) {
                recyclerView.visibility = View.VISIBLE
                contactLayout.visibility = View.GONE
            }

            if (category != "business") {
                category = "business"
                loadJSON("", category!!)
            }
        }

        t3.setOnClickListener {

            if ( recyclerView.visibility==View.GONE && contactLayout.visibility==View.VISIBLE) {
                recyclerView.visibility = View.VISIBLE
                contactLayout.visibility = View.GONE
            }

            if (category != "entertainment") {
                category = "entertainment"
                loadJSON("", category!!)
            }
        }

        t4.setOnClickListener {

            if ( recyclerView.visibility==View.GONE && contactLayout.visibility==View.VISIBLE) {
                recyclerView.visibility = View.VISIBLE
                contactLayout.visibility = View.GONE
            }

            if (category != "health") {
                category = "health"
                loadJSON("", category!!)
            }
        }

        t5.setOnClickListener {

            if ( recyclerView.visibility==View.GONE && contactLayout.visibility==View.VISIBLE) {
                recyclerView.visibility = View.VISIBLE
                contactLayout.visibility = View.GONE
            }

            if (category != "science") {
                category = "science"
                loadJSON("", category!!)
            }
        }

        t6.setOnClickListener {

            if ( recyclerView.visibility==View.GONE && contactLayout.visibility==View.VISIBLE) {
                recyclerView.visibility = View.VISIBLE
                contactLayout.visibility = View.GONE
            }

            if (category != "sports") {
                category = "sports"
                loadJSON("", category!!)
            }
        }

        t7.setOnClickListener {

            if ( recyclerView.visibility==View.GONE && contactLayout.visibility==View.VISIBLE) {
                recyclerView.visibility = View.VISIBLE
                contactLayout.visibility = View.GONE
            }

            if (category != "technology") {
                category = "technology"
                loadJSON("", category!!)
            }
        }

        t8.setOnClickListener {


            if ( recyclerView.visibility==View.VISIBLE && contactLayout.visibility==View.GONE) {

                recyclerView.visibility = View.GONE
                contactLayout.visibility = View.VISIBLE
            }
//            val fm = supportFragmentManager
//            fm.beginTransaction()
//                .replace(R.id.fragContainer, ContactDetails())
//                .commit()

        }



    }

    override fun onRefresh() {
        refreshLayout.isRefreshing = false
    }


    private fun loadJSON(keyword: String, category: String) {
        default_item!!.visibility = View.GONE
        refreshLayout.isRefreshing = true

        val apiInterface: ApiInterface? = ApiClient.apiClient?.create(ApiInterface::class.java)

        val country: String = Utils.country
        Log.d("MyTAg","country is $country")
        val language: String = Utils.language

        val call: Call<News?>? = if (keyword.isNotEmpty()) {
            apiInterface?.getNewsSearch(
                keyword,
                language,
                "publishedAt",
                getString(R.string.NewsApiKey)
            )
        } else {
            if (category.isNotEmpty()) {
                apiInterface?.getNewsByCategory(country, category, getString(R.string.NewsApiKey))
            } else {
                apiInterface?.getNews(country, getString(R.string.NewsApiKey))
            }
        }

        call!!.enqueue(object : Callback<News?> {
            override fun onResponse(call: Call<News?>, response: Response<News?>) {
                if (response.isSuccessful && response.body()?.article != null) {
                    if (articles.isNotEmpty()) {
                        articles.clear()
                    }

                    articles = response.body()!!.article?.toMutableList()!!

                    //For showing ads on indexes 4,9,14,19
//                    articles.add(4,articles[0])
//                    articles.add(9,articles[0])
//                    articles.add(14,articles[0])
//                    articles.add(19,articles[0])

                    adapter = Adapter(articles, this@MainActivity)
                    recyclerView.adapter = adapter
                    adapter!!.notifyDataSetChanged()
//                    initListener()

                    //topHeadline.setVisibility(View.VISIBLE);
                    refreshLayout.isRefreshing = false
                } else {

                    //topHeadline.setVisibility(View.INVISIBLE);
                    refreshLayout.isRefreshing = false
                    val errorCode: String = when (response.code()) {
                        404 -> "404 not found"
                        500 -> "500 server broken"
                        else -> "unknown error"
                    }
                    showErrorMessage(
                        R.drawable.no_result,
                        "No Result",
                        """
                        Please try again!
                        $errorCode
                        """.trimIndent()
                    )
                }
            }

            override fun onFailure(call: Call<News?>, t: Throwable) {
                //topHeadline.setVisibility(View.INVISIBLE);
                refreshLayout.isRefreshing = false
                showErrorMessage(R.drawable.oops, "Oops..", "You are not connected to the internet")
            }
        })
    }

    private fun showErrorMessage(imageView: Int, title: String, message: String) {
        if (default_item!!.visibility == View.GONE) {
            default_item!!.visibility = View.VISIBLE
        }
//        default_image!!.setImageResource(imageView)
//        default_title!!.text = title
//        default_text!!.text = message
        retry_btn!!.setOnClickListener { loadJSON("", "") }
    }

}


//    private fun initListener() {
//
//        adapter!!.setOnItemClickListener(object : Adapter.OnItemClickListener {
//
//           override fun onItemClick(view: View?, position: Int) {
//                val imageView = view?.findViewById<ImageView>(R.id.img)
//                /*Intent intent = new Intent(context, MainActivity.class);
//
//                intent.putExtra("url", article.getUrl());
//                intent.putExtra("title", article.getTitle());
//                intent.putExtra("img",  article.getUrlToImage());
//                intent.putExtra("date",  article.getPublishedAt());
//                intent.putExtra("source",  article.getSource().getName());
//                intent.putExtra("author",  article.getAuthor());*/
//                val article = articles[position]
//                val i = Intent(Intent.ACTION_VIEW)
//                i.data = Uri.parse(article.url)
//                startActivity(i)
//            }
//
//        })
//    }

    //        val adView: TemplateView = findViewById(R.id.addTemplate)

//            val adLoader:AdLoader = AdLoader.Builder(this, "ca-app-pub-3940256099942544/2247696110")
//            .forNativeAd { ad : NativeAd ->
//                // Show the ad.
//                addTemplate.setNativeAd(ad)
//
//            }
//            .withAdListener(object : AdListener() {
//                override fun onAdFailedToLoad(adError: LoadAdError) {
//                    // Handle the failure by logging, altering the UI, and so on.
//                }
//            })
//            .withNativeAdOptions(NativeAdOptions.Builder()
//                // Methods in the NativeAdOptions.Builder class can be
//                // used here to specify individual options settings.
//                .build())
//            .build()
//
////        val adLoader2 = adLoader.
//        val adReq=AdRequest.Builder().build()
//        adLoader.loadAd(adReq)


